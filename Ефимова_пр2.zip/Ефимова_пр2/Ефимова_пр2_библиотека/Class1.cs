﻿namespace Ефимова_пр2_библиотека

{
    public class Calculator
    {
        public double Add(double a, double b) => a + b;
        public double Subtract(double a, double b) => a - b;
        public double Multiply(double a, double b) => a * b;
        public double Divide(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("Деление на ноль!");
            return a / b;
        }

        public double Power(double a, double b)
        {
            return Math.Pow(a, b);
        }
    }
}