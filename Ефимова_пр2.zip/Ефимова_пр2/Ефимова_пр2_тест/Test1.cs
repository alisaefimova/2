﻿using Ефимова_пр2_библиотека;
namespace Ефимова_пр2_тест
{
    [TestClass]
    public class CalculatorTests
    {
        Calculator calc = new Calculator();

        [TestMethod]
        public void Add_Test()
        {
            Assert.AreEqual(5, calc.Add(2, 3));
        }

        [TestMethod]
        public void Divide_Test()
        {
            Assert.AreEqual(2, calc.Divide(4, 2));
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Divide_ByZero_Test()
        {
            calc.Divide(5, 0);
        }
    }
}